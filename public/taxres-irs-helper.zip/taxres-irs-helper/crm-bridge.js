// TaxRes IRS Helper — CRM bridge
// Handles the postMessage channel between this IRS page and the TaxRes CRM.
// Only accepts messages from this page's own origin (window.location.origin).
// Never reads, stores, or relays IRS / ID.me sign-in credentials.

const HELPER_SOURCE = 'taxres-irs-helper'
const CRM_SOURCE = 'taxres-crm'

// Read the pairing nonce the CRM embedded in the IRS URL fragment (#taxres-bind=<nonce>).
// The fragment is never sent to IRS servers — it stays in the browser.
// Once set, this page ONLY accepts crm-bind from the CRM tab that opened it with this nonce.
// A second agent cannot hijack this window's binding by sending a crm-bind with a different nonce.
const INITIAL_NONCE = (() => {
  try { return new URLSearchParams(location.hash.slice(1)).get('taxres-bind') || null } catch { return null }
})()

let crmWindow = null
let tenantId = null
let requestIds = null
let nonce = INITIAL_NONCE  // locked on load; not overwritten by later crm-bind from a different nonce
// agentName and clientId are stored from the original bind for logging/display only —
// they are not used for routing (routing uses requestIds + TIN match in the CRM).
let agentName = null
let clientId = null

// Exported so mailbox.js can use them
window.__taxresHelper = window.__taxresHelper || {}

function findOpener() {
  try {
    if (window.opener && !window.opener.closed) return window.opener
  } catch { /* cross-origin opener — normal for IRS popups */ }
  return null
}

function postToCrm(msg) {
  const w = crmWindow || findOpener()
  if (!w) return
  try {
    w.postMessage({ source: HELPER_SOURCE, ...msg }, '*')
  } catch { /* window may have navigated */ }
}

// Expose so mailbox.js can call postToCrm and read shared state
window.__taxresHelper.postToCrm = postToCrm
window.__taxresHelper.getState = () => ({ tenantId, requestIds, nonce, crmWindow, agentName, clientId })

window.addEventListener('message', (event) => {
  const data = event.data
  if (!data || data.source !== CRM_SOURCE) return

  // Accept messages from:
  //   (a) the same page itself via postMessage relay (same-origin same-window), OR
  //   (b) the CRM WindowProxy that sent us a prior crm-bind/crm-ping (stored in crmWindow), OR
  //   (c) window.opener on the very first contact, before crmWindow is set.
  // This means window.opener is a convenience/initial-contact path only — once crmWindow is
  // established from event.source of a crm-bind/crm-ping, it is the authoritative channel
  // and the flow works even if opener becomes null during IRS/ID.me navigation.
  const fromSelf = event.source === window && event.origin === window.location.origin
  const fromCrm = crmWindow ? event.source === crmWindow : event.source === findOpener()
  if (!fromSelf && !fromCrm) return

  if (data.type === 'crm-ready' || data.type === 'crm-hello') {
    crmWindow = event.source || findOpener()
    if (data.tenantId) tenantId = String(data.tenantId)
    postToCrm({ type: 'helper-hello', url: window.location.href })
    window.__taxresHelper.updatePanel?.('Ready — click a transcript to send it to the CRM.')
  }

  // crm-bind: sent by the CRM in response to helper-hello (on-demand rebind after navigation).
  // crm-ping: sent proactively by the CRM on an interval so the channel survives cases where
  //   window.opener became null during IRS/ID.me navigation (e.g. server-side 302 redirect).
  //   Handled identically to crm-bind — sets crmWindow and sends helper-hello back.
  if (data.type === 'crm-bind' || data.type === 'crm-ping') {
    // Nonce lock: if this page was opened with a pairing nonce (via #taxres-bind=<nonce>),
    // reject crm-bind/crm-ping from any other nonce. This prevents Agent B's CRM tab from
    // stealing the binding of Agent A's already-open IRS window.
    if (INITIAL_NONCE && data.nonce && data.nonce !== INITIAL_NONCE) return
    if (data.tenantId) tenantId = String(data.tenantId)
    if (Array.isArray(data.requestIds)) requestIds = data.requestIds.map(String)
    // Accept the nonce only from the originating CRM tab (same nonce); never overwrite with foreign nonce.
    if (!nonce && data.nonce) nonce = data.nonce
    // Store agent and client for logging/display — never used for routing
    if (data.agentName) agentName = String(data.agentName)
    if (data.clientId) clientId = String(data.clientId)
    // Learn the CRM window from event.source — this is the critical step that makes the channel
    // work even if window.opener was nulled by IRS/ID.me navigation after the initial page load.
    crmWindow = event.source || findOpener()
    postToCrm({ type: 'helper-hello', url: window.location.href })
    const who = agentName ? ` · ${agentName}` : ''
    window.__taxresHelper.updatePanel?.(`Linked to CRM${who} — click a transcript to send it.`)
  }

  if (data.type === 'crm-gone') {
    crmWindow = null
    window.__taxresHelper.updatePanel?.('CRM window closed. Reopen the CRM to link again.')
  }

  if (data.type === 'transcript-ack') {
    if (data.status === 'filed') {
      window.__taxresHelper.updatePanel?.(`✅ Filed to ${data.detail || 'client'}.`)
    } else if (data.status === 'duplicate') {
      window.__taxresHelper.updatePanel?.('ℹ Already filed — not filed again.')
    } else {
      window.__taxresHelper.updatePanel?.(`⚠ ${data.detail || 'Could not file. Try again or drag the file onto the CRM.'}`)
    }
  }
})

// On first load, try to announce via window.opener — this works when the IRS page loaded fresh
// and opener is still set. If opener is null (IRS/ID.me navigation already cleared it), the CRM's
// proactive crm-ping interval will reach us and set crmWindow from event.source instead.
// Either way crmWindow ends up set and the channel is live.
;(function announceToOpener() {
  const w = findOpener()
  if (!w) return
  crmWindow = w
  try {
    w.postMessage({ source: HELPER_SOURCE, type: 'helper-hello', url: window.location.href }, '*')
  } catch { /* noop */ }
})()
